def addition(a, b):
    # Function to add two numbers
    return a + b

def subtraction(a, b):
    # Function to subtract the second number from the first
    return a - b

def multiplication(a, b):
    # Function to multiply two numbers
    return a * b

def division(a, b):
    # Function to divide the first number by the second
    # Checks if the divisor is zero and prints a message if true
    if b == 0:
        print("Division by zero is not possible")
        return None  # Return None if division by zero
    return a / b

def main():
    while True:
        # Display operation options
        print("Select operation:")
        print("1. Addition")
        print("2. Subtraction")
        print("3. Multiplication")
        print("4. Division")
        print("5. Exit")
        
        # Get user input for operation choice
        choice = input("Enter choice (1/2/3/4/5): ")
        
        # Exit the program if the choice is 5
        if choice == '5':
            print("Exiting the calculator. Goodbye!")
            break
        
        # Check if the choice is one of the operation options
        if choice in ['1', '2', '3', '4']:
            # Get user input for the numbers to operate on
            a = int(input("Enter first number: "))
            b = int(input("Enter second number: "))
            
            # Perform the chosen operation
            if choice == '1':
                print(f"The result is: {addition(a, b)}")
            elif choice == '2':
                print(f"The result is: {subtraction(a, b)}")
            elif choice == '3':
                print(f"The result is: {multiplication(a, b)}")
            elif choice == '4':
                result = division(a, b)
                if result is not None:  # Only print result if it's not None
                    print(f"The result is: {result}")
        else:
            # Inform the user of an invalid choice
            print("Invalid choice! Please choose a valid operation.")

# Run the main function if this script is executed
if __name__ == "__main__":
    main()
